import { createStackNavigator } from "react-navigation-stack";
import { createAppContainer } from "react-navigation";
import Home from "./components/home/Home";
import HomeMicro from "./components/homeMicro/HomeMicro";
import Calculator from "./components/calculator/calculator";
import EndMicro from "./components/endMicro/endMicro";

const MainNavigator = createStackNavigator({
  Login: { screen: Home },
  EndMicro: { screen: EndMicro },
  Calculator: { screen: Calculator },
  HomeMicro: { screen: HomeMicro }
});

const App = createAppContainer(MainNavigator);

export default App;
