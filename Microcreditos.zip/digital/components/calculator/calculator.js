import React, { Component } from 'react';
import {
  Image,
  StyleSheet,
  Text,
  View,
  TextInput,
  SafeAreaView,
  ScrollView,
} from 'react-native';

import Button from 'react-native-button';
import Icon from 'react-native-vector-icons/FontAwesome';

const logoUri = `https://github.com/yeimmycl/digital/blob/master/assets/logo2.png?raw=true`;
const tarjeta =
  'https://github.com/yeimmycl/digital/blob/master/assets/tarjeta2.png?raw=true';

const Calculator = props => (
  <View style={styles.app}>
    <SafeAreaView>
      <ScrollView>
        <View style={styles.header}>
          <Icon name="bars" size={30} style={styles.icon} />
          <Image
            accessibilityLabel="React logo"
            source={{ uri: logoUri }}
            resizeMode="contain"
            style={styles.logo}
          />
          <Icon name="shopping-cart" size={30} style={styles.icon} />
        </View>
        <View style={styles.creditContainer}>
          <Text style={styles.title}>Crédito</Text>
          <Text style={styles.subTitle}>Calculadora de crédito</Text>
          <Text style={styles.label}>Valor del crédito</Text>
          <TextInput style={styles.textInput} value={'$15.000.000'} />
          <Text style={styles.label}>Tiempo de pago (Meses)</Text>
          <TextInput style={styles.textInput} value={'36'} />
          <View style={styles.resume}>
            <View style={styles.hr} />
            <Text style={styles.resumeTitle}>Resumen del crédito</Text>
            <View style={styles.hrContainer}>
              <Text style={styles.textTitle}>Tasa de interés:</Text>
              <Text style={styles.text}>10% E.A.</Text>
            </View>
            <View style={styles.hrContainer}>
              <Text style={styles.textTitle}>Pago por intereses:</Text>
              <Text style={styles.text}>$4.965.000</Text>
            </View>
            <View style={styles.hrContainer}>
              <Text style={styles.textTitle}>Total crédito:</Text>
              <Text style={styles.text}>$19.965.000</Text>
            </View>
          </View>
        </View>
        <Icon.Button
          name="arrow-right"
          style={styles.buttonInterest}
          backgroundColor="white"
          color="black"
          onPress={() => props.navigation.navigate('EndMicro')}>
          Tomar el crédito
        </Icon.Button>
      </ScrollView>
    </SafeAreaView>
  </View>
);

const styles = StyleSheet.create({
  app: {
    marginHorizontal: 'auto',
    maxWidth: 500,
  },
  resume: {
    borderColor: '#DFE0E5',
    borderWidth: 2,
  },
  hr: {
    height: 10,
    backgroundColor: '#F76C6F',
  },
  resumeTitle: {
    fontSize: 20,
    alignSelf: 'center',
    fontWeight: 'bold',
  },
  textTitle: {
    fontSize: 18,
    alignSelf: 'center',
    fontWeight: 'bold',
  },
  text: {
    alignSelf: 'center',
    fontSize: 16,
    marginLeft: 10,
  },
  hrContainer: {
    display: 'flex',
    flexDirection: 'row',
    marginVertical: 15,
  },
  textInput: {
    height: 50,
    marginBottom: 30,
    borderBottomColor: '#DFE0E5',
    borderBottomWidth: 2,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  creditContainer: { paddingHorizontal: 16 },
  subTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 15,
    color: '#F76C6F',
  },
  logo: {
    height: 50,
    marginVertical: 10,
    minWidth: 300,
  },
  header: {
    display: 'flex',
    flexDirection: 'row',
  },
  icon: {
    paddingHorizontal: 15,
    alignSelf: 'center',
  },
  buttonInterest: {
    backgroundColor: 'white',
    color: '#00000',
    height: 60,
    padding: 15,
    borderRadius: 30,
    marginVertical: 15,
    marginHorizontal: 30,
    borderColor: 'black',
    borderWidth: 2,
  },
});

export default Calculator;
