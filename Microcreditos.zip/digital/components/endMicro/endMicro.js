import React, { Component } from 'react';
import {
  Image,
  StyleSheet,
  Text,
  View,
  TextInput,
  SafeAreaView,
  ScrollView,
} from 'react-native';

import Button from 'react-native-button';
import Icon from 'react-native-vector-icons/FontAwesome';

const logoUri = `https://github.com/yeimmycl/digital/blob/master/assets/logo2.png?raw=true`;
const imgThanks =
  'https://github.com/yeimmycl/digital/blob/master/assets/5%20Copy%202.png?raw=true';

const EndMicro = props => (
  <View style={styles.app}>
    <SafeAreaView>
      <ScrollView>
        <View style={styles.header}>
          <Icon name="bars" size={30} style={styles.icon} />
          <Image
            accessibilityLabel="React logo"
            source={{ uri: logoUri }}
            resizeMode="contain"
            style={styles.logo}
          />
          <Icon name="shopping-cart" size={30} style={styles.icon} />
        </View>
        <View style={styles.thanks}>
          <Text style={styles.title}>Tu crédito ha sido solicitado</Text>
          <Text style={styles.title}>exitosamente!!!</Text>
          <Text style={styles.subtitle}>Por un valor de $15.000.000</Text>
          <Image
            accessibilityLabel="React logo"
            source={{ uri: imgThanks }}
            resizeMode="contain"
            style={styles.thanksImg}
          />
          <Text style={styles.asesor}>Un asesor se contactará contigo</Text>
          <Text style={styles.asesor}>en 3 días hábiles</Text>
        </View>
        <Icon.Button
          name="home"
          style={styles.buttonInterest}
          backgroundColor="white"
          onPress={() => props.navigation.navigate('HomeMicro')}>
          Ir al inicio
        </Icon.Button>
      </ScrollView>
    </SafeAreaView>
  </View>
);

const styles = StyleSheet.create({
  app: {
    marginHorizontal: 'auto',
    maxWidth: 500,
  },
  asesor: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 15,
    textAlign: 'center',
    color: '#F76C6F',
  },
  thanksImg: {
    minWidth: 250,
    height: 200,
  },
  thanks: { paddingHorizontal: 16 },
  title: {
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 50,
    marginVertical: 10,
    minWidth: 300,
  },
  header: {
    display: 'flex',
    flexDirection: 'row',
  },
  icon: {
    paddingHorizontal: 15,
    alignSelf: 'center',
  },
  buttonInterest: {
    backgroundColor: '#F76C6F',
    color: 'white',
    height: 60,
    fontSize: 18,
    padding: 15,
    borderRadius: 30,
    marginVertical: 15,
    marginHorizontal: 30,
    borderColor: '#F76C6F',
    borderWidth: 2,
    width: 150,
  },
});

export default EndMicro;
