import React, { Component } from 'react';
import {
  Image,
  StyleSheet,
  Text,
  View,
  TextInput,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import { NavigationActions } from 'react-navigation';

import Button from 'react-native-button';

const logoUri = `https://github.com/yeimmycl/digital/blob/master/assets/logo2.png?raw=true`;
const huellaUri =
  'https://github.com/yeimmycl/digital/blob/master/assets/touch.png?raw=true';

const Home = props => (
  <SafeAreaView>
    <ScrollView>
      <View style={styles.app}>
        <View style={styles.header}>
          <Image
            accessibilityLabel="React logo"
            source={{ uri: logoUri }}
            resizeMode="contain"
            style={styles.logo}
          />
        </View>
        <View>
          <View style={styles.container}>
            <Text style={styles.title}>Bienvenidos</Text>
            <Text style={styles.subtitle}>Ingresa a tu cuenta</Text>
            <TextInput style={styles.textInput} value={'Usuario 1'} />
            <TextInput style={styles.textInput} value={'************'} />
            <Image
              accessibilityLabel="React logo"
              source={{ uri: huellaUri }}
              resizeMode="contain"
              style={styles.huella}
            />
            <Text style={styles.forgot}>Olvidaste tu contraseña?</Text>
            <Button
              style={styles.buttonPrimary}
              onPress={() => props.navigation.navigate('HomeMicro')}>
              Login
            </Button>
          </View>
        </View>
      </View>
    </ScrollView>
  </SafeAreaView>
);

const styles = StyleSheet.create({
  app: {
    maxWidth: 500,
  },
  huella: {
    marginVertical: 16,
    height: 80,
  },
  logo: {
    height: 80,
    marginTop: 30
  },
  textInput: {
    height: 50,
    marginVertical: 16,
    borderBottomColor: '#DFE0E5',
    borderBottomWidth: 2,
  },
  header: {
    paddingBottom: 20,
  },
  title: {
    fontWeight: 'bold',
    fontSize: 24,
    marginVertical: 16,
    textAlign: 'center',
  },
  subtitle: {
    fontWeight: 'bold',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 16,
  },
  buttonPrimary: {
    backgroundColor: '#F76C6F',
    color: 'white',
    height: 60,
    padding: 15,
    borderRadius: 30,
    marginVertical: 15,
  },
  container: {
    flex: 1,
    width: 400,
    padding: 16,
    opacity: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowColor: 'black',
    shadowOffset: { height: 0, width: 0 },
  },
});

export default Home;
