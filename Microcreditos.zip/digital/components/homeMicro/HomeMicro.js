import React, { Component } from 'react';
import {
  Image,
  StyleSheet,
  Text,
  View,
  TextInput,
  SafeAreaView,
  ScrollView,
} from 'react-native';

import Button from 'react-native-button';
import Icon from 'react-native-vector-icons/FontAwesome';

const logoUri = `https://github.com/yeimmycl/digital/blob/master/assets/logo2.png?raw=true`;
const tarjeta =
  'https://github.com/yeimmycl/digital/blob/master/assets/tarjeta2.png?raw=true';

const HomeMicro = props => (
  <View style={styles.app}>
    <SafeAreaView>
      <ScrollView>
        <View style={styles.header}>
          <Icon name="bars" size={30} style={styles.icon} />
          <Image
            accessibilityLabel="React logo"
            source={{ uri: logoUri }}
            resizeMode="contain"
            style={styles.logo}
          />
          <Icon name="shopping-cart" size={30} style={styles.icon} />
        </View>
        <View style={styles.container}>
          <Image
            accessibilityLabel="React logo"
            source={{ uri: tarjeta }}
            resizeMode="contain"
            style={styles.tarjeta}
          />
        </View>
        <View style={styles.containerCard}>
          <Text style={styles.nameCard}> Jorge Arias</Text>
          <Text style={styles.descCard}>Tienes un prestamo pre-aprobado</Text>
          <Text style={styles.descCard}>por</Text>
          <View style={styles.descCardContainer}>
            <Text style={styles.numCard}> $15.000.000</Text>
            <Icon name="bell" size={30} style={styles.bell} />
          </View>
        </View>
        <Icon.Button
          name="arrow-right"
          style={styles.buttonInterest}
          backgroundColor="white"
          color="black"
            onPress={() => props.navigation.navigate('Calculator')}>
          Estoy interesado
        </Icon.Button>
        <View style={styles.containerButton}>
          <View style={styles.hr} />
          <View style={styles.hrContainer}>
            <Icon name="dollar" size={40} style={styles.iconCardButton} />
            <Text style={styles.textButton}>Pagar mi factura</Text>
          </View>
        </View>
        <View style={styles.containerButton}>
          <View style={styles.hr} />
          <View style={styles.hrContainer}>
            <Icon name="mobile-phone" size={45} style={styles.iconCardButton} />
            <Text style={styles.textButton}>Mejora tu plan</Text>
          </View>
        </View>
        <View style={styles.containerButton}>
          <View style={styles.hr} />
          <View style={styles.hrContainer}>
            <Icon name="user-circle" size={40} style={styles.iconCardButton} />
            <Text style={styles.textButton}>Atención en línea</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  </View>
);

const styles = StyleSheet.create({
  app: {
    marginHorizontal: 'auto',
    maxWidth: 500,
  },
  iconCardButton: { marginHorizontal: 10 },
  hr: {
    height: 10,
    backgroundColor: '#F76C6F',
  },
  hrContainer: {
    padding: 15,
  },
  containerButton: {
    marginVertical: 15,
    marginHorizontal: 30,
    borderColor: '#CCCCCC',
    borderWidth: 2,
  },
  bell: {
    marginVertical: 15,
    marginLeft: 10,
  },
  buttonInterest: {
    backgroundColor: 'white',
    color: '#00000',
    height: 60,
    padding: 15,
    borderRadius: 30,
    marginVertical: 15,
    marginHorizontal: 30,
    borderColor: 'black',
    borderWidth: 2,
  },
  nameCard: {
    fontSize: 25,
    color: 'white',
    marginVertical: 15,
    fontWeight: 'bold',
  },
  descCard: {
    fontSize: 14,
    color: 'white',
  },
  numCard: {
    fontSize: 20,
    color: 'white',
    fontWeight: 'bold',
    marginVertical: 10,
  },
  containerCard: {
    position: 'absolute',
    top: 100,
    left: 60,
    right: 0,
    bottom: 0,
  },
  logo: {
    height: 50,
    marginVertical: 10,
    minWidth: 300,
  },
  tarjeta: {
    height: 250,
    marginVertical: 10,
    minWidth: 300,
  },
  descCardContainer: {
    display: 'flex',
    flexDirection: 'row',
  },
  header: {
    display: 'flex',
    flexDirection: 'row',
  },
  icon: {
    marginHorizontal: 15,
    alignSelf: 'center',
  },
});

export default HomeMicro;
